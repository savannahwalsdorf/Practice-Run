﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
      internal class Program
        {
            private static string log;

            static void Main(string[] args)
            {
                Students s0 = new Students("A00191567", "Walsdorf", "Savannah", true);
                Students s1 = new Students("Urbach", "Jared", false);
                Students s2 = new Students("Slattery", "Angela",  true);
                Students s3 = new Students("Giles", "Jessi", "Computer science", DateTime.Today, DateTime.MinValue, "SD", "USA", "jessgiles@trojans.dsu.edu", "312-759-9804", "NW 3rd street Madiosn", false);
                Students s4 = new Students("Gregor", "John", false);
                Students s5 = new Students("A00987643","Smite","Alex", "Computer Science", DateTime.Today, DateTime.MinValue, "CA", "USA", "alexsmite@trojans.dsu.edu", "528-754-8301", "Washington 4th Sandiego", false);
                Students s6 = new Students("A00034832", "Vance", "Bob", false);
                Students s7 = new Students("Scott", "Michael", false);
                Students s8 = new Students("Halpert", "Jim", "Psychology", DateTime.MinValue, DateTime.Today, "NewYork", "USA", "jimhalpert@trojans.dsu.edu", "578-608-4528", "Dakota Ave Charolletesville", true);
                Students s9 = new Students("47923090", "Richards", "Sam", "Math", DateTime.Today, DateTime.MinValue, "Georgia", "USA", "samrichards@trojans.dsu.edu", "920-679-9814", "Lincoln 1st Atlanta", true);

                Students[] s = { s0, s1, s2, s3, s4, s5, s6, s7, s8, s9 };

                foreach (Students stud in s)
                {
                    string name = stud.Name;
                    string id = stud.Studentsid;
                    string major = stud.Major;
                    string address = stud.Address;
                    string state = stud.StateAndProvince;
                    string country = stud.Country;
                    string email = stud.EmailAddress;
                    string phone = stud.Phone;
                    string startDate = stud.StartDate.ToString();
                    string gradDate = stud.GradDate.ToString();
                    Console.WriteLine("{0}, {1} majoring in {9},  {2}, {3}, {4},  {5}, {6},  {7}-{8}",
                        id, name, address, state, country, phone, email, startDate, gradDate, major);
                }

                Console.Write(log);
                Console.ReadLine();
            }

            public static void AddToLog(string studentsid, string field, string value)
            {
                string fRecord = String.Format($"{studentsid,-12}{field,-20}{value,-20}\n", studentsid, field, value);
                log += fRecord;
            }
        }
}
