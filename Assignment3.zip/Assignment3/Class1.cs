﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
	internal class Students
	{
		private string _Studentsid;
		private string _lastName;
		private string _firstName;
		private string _major;
		private DateTime _startDate;
		private DateTime _gradDate;
		private string _state;
		private string _country;
		private string _email;
		private string _phone;
		private string _address;
		private bool _Hidden;

		public string Studentsid
		{
			get { return _Studentsid; }
		}

		public string LastName
		{
			get { return _lastName; }
			set
			{
				_lastName = value;
				Program.AddToLog(this.Studentsid, "LastName", value);
			}
		}

		public string FirstName
		{
			get { return _firstName; }
			set
			{
				_firstName = value;
				Program.AddToLog(this.Studentsid, "FirstName", value);
			}
		}

		public string Name
		{
			get
			{
				return _firstName + " " + _lastName;
			}
		}

		public string Major
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _major;
				}
			}
			set
			{
				_major = value;
				Program.AddToLog(this.Studentsid, "Major", value);
			}
		}
		public string Address
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _address;
				}
			}
			set
			{
				_address = value;
				Program.AddToLog(this.Studentsid, "HomeAddress", value);
			}
		}


		public string StateAndProvince
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _state;
				}
			}
			set
			{
				_state = value;
				Program.AddToLog(this.Studentsid, "StateAndProvince", value);
			}
		}

		public string Country
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _country;
				}
			}
			set
			{
				_country = value;
				Program.AddToLog(this.Studentsid, "Country", value);
			}
		}

		public string EmailAddress
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _email;
				}
			}
			set
			{
				_email = value;
				Program.AddToLog(this.Studentsid, "EmailAddress", value);
			}
		}

		public string Phone
		{
			get
			{
				if (_Hidden)
				{
					return "WithHoldingInfo";
				}
				else
				{
					return _phone;
				}
			}
			set
			{
				_phone = value;
				Program.AddToLog(this.Studentsid, "Phone", value);
			}
		}
		public DateTime StartDate
		{
			get => _startDate;
		}

		public DateTime GradDate
		{
			get { return _startDate; }
			set
			{
				_gradDate = value;
				Program.AddToLog(this.Studentsid, "gradDate", value.ToString());
			}
		}


		public bool Hidden
		{
			get => _Hidden;
		}

		public Students(string id, string lastName, string firstName, string major, DateTime startDate, DateTime gradDate,
				string stateAndProvince, string country, string email, string phone, string address, bool Hidden)
		{
			_Studentsid = id;
			_lastName = lastName;
			_firstName = firstName;
			_major = major;
			_startDate = startDate;
			_gradDate = gradDate;
			_state = stateAndProvince;
			_country = country;
			_email = email;
			_phone = phone;
			_address = address;
			_Hidden = Hidden;
		}

		public Students(string lastName, string firstName, string major, DateTime startDate, DateTime gradDate,
				string stateAndProvince, string country, string email, string phone, string address, bool Hidden) :
				this("", lastName, firstName, major, startDate, gradDate, stateAndProvince, country, email, phone, address,
				Hidden)
		{
			Random rand = new Random();
			_Studentsid = rand.Next(10000000, 99999999).ToString();
		}

		public Students(string Studentsid, string lastName, string firstName, bool Hidden) :
				this(Studentsid, lastName, firstName, "No major", DateTime.MinValue, DateTime.MaxValue,
					"N/A", "N/A", "N/A", "N/A", "N/A", Hidden)
		{

		}

		public Students(string lastName, string firstName, bool Hidden) :
				this("", lastName, firstName, "No major", DateTime.MinValue, DateTime.MaxValue,
					"N/A", "N/A", "N/A", "N/A", "N/A", Hidden)
		{
			Random rand = new Random();
			_Studentsid = rand.Next(10000000, 99999999).ToString();
		}

	}
}
